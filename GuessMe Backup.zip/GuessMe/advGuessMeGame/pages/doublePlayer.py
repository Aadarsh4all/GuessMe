import flet as ft
from random import randint

def main(page = ft.Page):
     #page.title = "GUESS ME"
     #page.vertical_alignment = ft.MainAxisAlignment.CENTER
     page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
     page.window_height = 500
     page.window_width = 450
     page.padding = 20
     
     # Answer Key
     answerRand = randint(1,100)
     
      # Fonts
     page.fonts = {
         "fnt_Reydex" : "Reydex-vm6xM.otf",
         "fnt_Ubuntu" : "ubuntu.ttf"
     }
     
     
     
     # Player Text Feild
     check_player1 = ft.TextField(hint_text="Guess A Number", label="Player 1", width=150)
     check_player2 = ft.TextField(hint_text="Guess A Number", label="Player 2", width=150)
     
     
     
     # Result
     result = ft.Text(font_family="fnt_Ubuntu", size=18)
    
     
     print(f"=>", answerRand)
     
     # Check Answer Player1
     def checkAns_player1(e):
        if float(check_player1.value ) > answerRand:
            result.value = "Guess A Lower Value"
            
        elif float(check_player1.value ) < answerRand:
            result.value = "Guess A Higher Value"
            
        elif float(check_player1.value ) == answerRand:
            result.value = "Yep! Player 1 Won The Match"
            
        else:
            result.value = "oh! Something Went Wrong"
        
        page.update()     
            
            
    # Check Answer Player2
     def checkAns_player2(e):
        if float(check_player2.value ) > answerRand:
            result.value = "Guess A Lower Value"
            
        elif float(check_player2.value ) < answerRand:
            result.value = "Guess A Higher Value"
            
        elif float(check_player2.value ) == answerRand:
            result.value = "Yep! Player 1 Won The Match"
            
        else:
            result.value = "oh! Something Went Wrong"
        
        page.update()    
             

         
     
     # Player Enter Btn
     btn_player1 = ft.OutlinedButton("Guess", on_click=checkAns_player1)
     btn_player2 = ft.OutlinedButton("Guess", on_click=checkAns_player2)
     
     
     
    
     # Page Heading
     heading = ft.Card(
                    ft.Container(
                        content=
                        ft.Row(
                        controls= [ft.Text(f"GuessMe upto 100", size=20,)],
                        alignment = "center",
                        ), padding=10
                    )
                )
     
     
     
     page.add(
         
         heading,
         
         ft.Column(
             [
                 ft.Row(
                  [
                      check_player1,
                      btn_player1
                  ], alignment="center"
                 ),
                 
                 
                
                ft.Row(
                  [
                      check_player2,
                      btn_player2
                  ], alignment="center" 
                 ),
                
                
                
                ft.Container(
                    content=
                     result, padding=30
                )
                
               
             ], horizontal_alignment="center"
         )
     )
    
    
ft.app(target=main)