import flet as ft
from random import randint



class mainPage:
    def main(page = ft.Page):
        #page.title = "GUESS ME"
        #page.vertical_alignment = ft.MainAxisAlignment.CENTER
        page.horizontal_alignment = ft.MainAxisAlignment.CENTER
        #  page.window_height =  800
        #  page.window_width =  480
        page.padding = 0
        
        page.theme_mode = "auto"
        
        # Fonts
        page.fonts = {
            "fnt_Reydex" : "fonts/Reydex-vm6xM.otf",
            "fnt_Ubuntu" : "fonts/ubuntu.ttf",
            "fnt_MonoT"  : "fonts/MonoT.ttf"
        }
        
        
        
        # AppBar 
        page.appbar = ft.AppBar(
            leading=ft.IconButton(ft.icons.NUMBERS_SHARP),
            leading_width=70,
            title=ft.Text("~ Guess Me", weight=ft.FontWeight.W_100, font_family="fnt_MonoT", size=16),
            center_title=True,
            bgcolor="#363636",
            toolbar_height=40,
            actions=[
                ft.IconButton(ft.icons.CIRCLE_ROUNDED , icon_color="#fd5754" , icon_size=18 , tooltip="End"    , width=25),
                ft.IconButton(ft.icons.CIRCLE_ROUNDED , icon_color="#febb40" , icon_size=18 , tooltip="Pause"  , width=25),
                ft.IconButton(ft.icons.CIRCLE_ROUNDED , icon_color="#34c848" , icon_size=18 , tooltip="Resume" , width=25), 
                ft.Text("", width=18)

                # ft.PopupMenuButton(
                #     items=[
                #         ft.PopupMenuItem(text="Item 1"),
                #         ft.PopupMenuItem(),  # divider
                #         ft.PopupMenuItem(
                #             text="Checked item", checked=False
                #         ),
                #     ]
                # ),
            ], 
        )
        


        # head1 = ft.Text("Get your game, ", size=18, font_family="fnt_Ubuntu", text_align="CENTER")

        coominsoon = ft.Text("Just Coming...."),
        spaces = ft.Text("",width=18, height=10)
        head1 = ft.Container(
                    content=ft.Column(
                        [
                            ft.Text("  Get your game, ", size=18, font_family="fnt_Ubuntu", text_align="CENTER")

                        ], alignment="CENTER",
                    ),
                )
        
        # Routing
        def rout_youVsComp(e):
            page.route = "pages/YOUvsCOMP.py"
            page.update()
        
        
        
        
        # buttons
        btn1 = ft.ElevatedButton(
                content=ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(f"1 VS Comp", font_family="fnt_MonoT", size=25, text_align="CENTER"),
                            # ft.ListTile(
                            #     title=ft.Text("The Enchanted "),
                            #     subtitle=ft.Text(
                            #         "Music by Julie "
                            #     ),
                            # ),
                        ], alignment="center",
                    ),
                    width=120,
                    height=130,
                    padding=-8,
                    on_click=rout_youVsComp
                ),
                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=15)),
                #style=ft.ButtonStyle(shape={ft.MaterialState.DEFAULT: RoundedRectangleBorder(radius=20)})
            )
        
        btn2 = ft.ElevatedButton(
                content=ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(f" 1 vs 1", font_family="fnt_MonoT", size=25, text_align="CENTER"),
                            # ft.ListTile(
                            #     title=ft.Text("The Enchanted "),
                            #     subtitle=ft.Text(
                            #         "Music by Julie "
                            #     ),
                            # ),
                        ], alignment="center",
                    ),
                    width=120,
                    height=130,
                    padding=2
                ),
                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=15)),
                #style=ft.ButtonStyle(shape={ft.MaterialState.DEFAULT: RoundedRectangleBorder(radius=20)})
            )
        
        
        btn3 = ft.ElevatedButton(
                content=ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(f"     Custom Game", font_family="fnt_MonoT", size=25, text_align="CENTER"),
                            # ft.ListTile(
                            #     title=ft.Text("The Enchanted "),
                            #     subtitle=ft.Text(
                            #         "Music by Julie "
                            #     ),
                            # ),
                        ], alignment="center",
                    ),
                    width=300,
                    height=100,
                    #padding=20
                ), 
                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=15)),
                #style=ft.ButtonStyle(shape={ft.MaterialState.DEFAULT: RoundedRectangleBorder(radius=20)})
            )
        
        
        
        btn4 = ft.ElevatedButton(
                content=ft.Container(
                    content=ft.Column(
                        [
                            ft.Text(f"    Online Multiplayer", font_family="fnt_MonoT", size=20, text_align="CENTER"), ft.Text(f"                Coming Soon", font_family="fnt_MonoT", size=12)
                            # ft.ListTile(
                            #     title=ft.Text("The Enchanted "),
                            #     subtitle=ft.Text(
                            #         "Music by Julie "
                            #     ),
                            # ),
                        ], alignment="center",
                    ),
                    width=300,
                    height=70,
                    #padding=20
                    on_click=lambda _: page.go('pages/doublePlayer')
                ), 
                style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=15)),
                #style=ft.ButtonStyle(shape={ft.MaterialState.DEFAULT: RoundedRectangleBorder(radius=20)})
            )
        
        
        
                    
        # groups/col
        col1 = ft.Column([ft.Row([btn1,btn2],alignment="center")])
        col2 = ft.Column([ft.Row([btn3],alignment="center")])
        col3 = ft.Column([ft.Row([btn4],alignment="center")])


        page.add(
            spaces, head1, spaces, col1, spaces, col2, spaces, col3
        )
        
    ft.app(target=main, assets_dir="assets")